/*
SQLyog Ultimate v11.11 (32 bit)
MySQL - 5.5.5-10.4.20-MariaDB : Database - midterm-2023
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`midterm-2023` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `midterm-2023`;

/*Table structure for table `cap_table` */

DROP TABLE IF EXISTS `cap_table`;

CREATE TABLE `cap_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `share_class_id` int(10) unsigned NOT NULL,
  `share_class_category_id` int(10) unsigned NOT NULL,
  `investor_id` int(10) unsigned NOT NULL,
  `diluted_shares` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_share_class_id` (`share_class_id`),
  KEY `fk_share_class_category_id` (`share_class_category_id`),
  KEY `fk_investor_id` (`investor_id`),
  CONSTRAINT `fk_investor_id` FOREIGN KEY (`investor_id`) REFERENCES `investors` (`id`),
  CONSTRAINT `fk_share_class_category_id` FOREIGN KEY (`share_class_category_id`) REFERENCES `share_class_categories` (`id`),
  CONSTRAINT `fk_share_class_id` FOREIGN KEY (`share_class_id`) REFERENCES `share_classes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `cap_table` */

insert  into `cap_table`(`id`,`share_class_id`,`share_class_category_id`,`investor_id`,`diluted_shares`) values (1,1,1,1,50.00),(2,1,2,1,10.00),(3,2,3,1,89.00),(4,2,4,2,12.00),(5,1,2,2,13.00),(6,2,3,3,15.00),(7,1,1,7,11.00),(8,2,4,2,18.00),(10,1,1,1,103.00),(11,1,1,1,123.00);

/*Table structure for table `investors` */

DROP TABLE IF EXISTS `investors`;

CREATE TABLE `investors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `investors` */

insert  into `investors`(`id`,`first_name`,`last_name`,`email`,`company`,`created_at`) values (1,'FIRST ','INVESTOR','first.investor@gmail.com','ONE','2023-04-06 09:25:16'),(2,'SECOND','INVESTOR','second.investor@gmail.com','TWO','2023-04-12 09:25:16'),(3,'THIRD','INVESTOR','third.investor@gmail.com','THREE','2023-04-18 09:25:16'),(7,'FOURTH','INVESTOR','fourth.investor@gmail.com','FOUR','2023-04-18 09:25:16'),(8,'dze','me','d@gmail.com','Co',NULL),(9,'dze','me','d4@gmail.com','Co','2023-07-04 17:22:48'),(10,'dze','me','d4@gmail.com','Co','2023-07-04 17:22:56'),(11,'dze','me','d5@gmail.com','Co','2023-07-04 17:23:08'),(12,'dze','me','d6@gmail.com','Co','2023-07-04 17:26:21'),(13,'dze','me','d9@gmail.com','Co',NULL),(14,'dze','me','d10@gmail.com','Co',NULL),(15,'dze','me','d100@gmail.com','Co',NULL),(16,'dze','me','dzelila100@gmail.com','Co',NULL),(17,'dze','me','dzelila110@gmail.com','Co',NULL),(18,'dze','me','dzelila18@gmail.com','Co',NULL),(19,'dze','me','dzelila1@gmail.com','Co',NULL),(20,'dze','me','dzeldvila1@gmail.com','Co',NULL),(21,'dze','me','amle@gmail.com','Co',NULL);

/*Table structure for table `locations` */

DROP TABLE IF EXISTS `locations`;

CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Country` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Region` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `City` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `locations` */

insert  into `locations`(`id`,`form`,`to`,`Country`,`Region`,`City`,`code`) values (1,'1','1','1','1','1','1');

/*Table structure for table `share_class_categories` */

DROP TABLE IF EXISTS `share_class_categories`;

CREATE TABLE `share_class_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `share_class_id` int(10) unsigned NOT NULL,
  `description` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_share_class` (`share_class_id`),
  CONSTRAINT `fk_share_class` FOREIGN KEY (`share_class_id`) REFERENCES `share_classes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `share_class_categories` */

insert  into `share_class_categories`(`id`,`share_class_id`,`description`) values (1,1,'CATEGORY_1'),(2,1,'CATEGORY_2'),(3,2,'CATEGORY_3'),(4,2,'CATEGORY_4');

/*Table structure for table `share_classes` */

DROP TABLE IF EXISTS `share_classes`;

CREATE TABLE `share_classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `equity_main_currency` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,6) DEFAULT NULL,
  `authorized_assets` decimal(20,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `share_classes` */

insert  into `share_classes`(`id`,`description`,`equity_main_currency`,`price`,`authorized_assets`) values (1,'FIRST_CLASS','USD',12.000000,500000000000.000),(2,'SECOND_CLASS','USD',29.000000,100000000000.000);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`first_name`,`last_name`,`email`,`password`) values (1,'demo','user','demo.user@gmail.com','123');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
