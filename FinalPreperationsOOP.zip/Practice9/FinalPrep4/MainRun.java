package org.example.Practice.Practice9.FinalPrep4;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

enum TextFormatter{
    ORDINARY, UPPER_CASE, LOWER_CASE;
}
enum NumberFormatter{
    CURRENCY, PERCENTAGE;
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface FieldFormat{
    TextFormatter text_format() default TextFormatter.ORDINARY;
    NumberFormatter number_format() default NumberFormatter.CURRENCY;
}

class Movie{
    @FieldFormat
    private Date releaseDate;
    @FieldFormat(text_format=TextFormatter.ORDINARY)
    private String title;
    @FieldFormat(number_format=NumberFormatter.CURRENCY)
    private double boxOffice;
    @FieldFormat(number_format=NumberFormatter.PERCENTAGE)
    private double rating;
    @FieldFormat(text_format=TextFormatter.UPPER_CASE)
    private String genre;
    @FieldFormat(text_format=TextFormatter.UPPER_CASE)
    private String director;
    @FieldFormat(text_format=TextFormatter.LOWER_CASE)
    private String language;

    public Date getDate(){
        return releaseDate;
    }
    public String getTitle(){
        return title;
    }
    public double getBoxOffice(){
        return boxOffice;
    }
    public double getRating(){
        return rating;
    }
    private String getGenre(){
        return genre;
    }
    private String getDirector(){
        return director;
    }
    private String getLanguage(){
        return language;
    }
    public Movie(MovieBuilder builder){
        this.releaseDate=builder.releaseDate;
        this.title=builder.title;
        this.boxOffice=builder.boxOffice;
        this.rating=builder.rating;
        this.genre=builder.genre;
        this.director=builder.director;
        this.language=builder.language;
    }


    public static class MovieBuilder{
        private Date releaseDate;
        private String title;
        private double boxOffice;
        private double rating;
        private String genre;
        private String director;
        private String language;
        public MovieBuilder(){}

        public MovieBuilder setReleaseDate(Date releaseDate){
            this.releaseDate=releaseDate;
            return this;
        }
        public MovieBuilder setTitle(String title){
            this.title=title;
            return this;
        }
        public MovieBuilder setBoxOffice(double boxOffice){
            this.boxOffice=boxOffice;
            return this;
        }
        public MovieBuilder setRating(double rating){
            this.rating=rating;
            return this;
        }
        public MovieBuilder setGenre(String genre){
            this.genre=genre;
            return this;
        }
        public MovieBuilder setDirector(String director){
            this.director=director;
            return this;
        }
        public MovieBuilder setLanguage(String language){
            this.language=language;
            return this;
        }
        public Movie build(){
            return new Movie(this);
        }
    }
}
class InvalidMovieException extends RuntimeException{
    public InvalidMovieException(String message){
        throw new InvalidMovieException(message);
    }
    public InvalidMovieException(String message, Throwable cause){
        throw new InvalidMovieException(message, cause);
    }
}

class MovieLoader{
    public static List<Movie> loadMovies(String fileName){
        List<Movie> movies=new ArrayList<>();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        int LineCounter=0;

        try(BufferedReader reader= new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine(); //Skip header
            if(line==null){
                throw new WrongThreadException("The file is empty");
            }
            while((line=reader.readLine())!=null) {


                String fields[] = line.split(",");
                if (fields[0].isEmpty() | fields[1].isEmpty() | fields.length > 7) {
                    throw new InvalidMovieException("Invalid data", new ClassCastException());
                }
                movies.add(new Movie.MovieBuilder()
                        .setReleaseDate(sdf.parse(fields[0]))
                        .setTitle(fields[1])
                        .setBoxOffice(Double.parseDouble(fields[2]))
                        .setRating(Double.parseDouble(fields[3]))
                        .setGenre(fields[4])
                        .setDirector(fields[4])
                        .setLanguage(fields[4])
                        .build());
            }
        }catch(IOException | ParseException e ){
            throw new InvalidMovieException("Invalid data", e);

        }
        return movies;
    }
}
class ReportWriter{
    public static void generateReport(String outputFileName, List<Movie> movies){

    }
}

public class MainRun {
    public static void main(String[] args) {
        String fileName="movies.csv";
        List<Movie> movies=MovieLoader.loadMovies(fileName);
    }
}
