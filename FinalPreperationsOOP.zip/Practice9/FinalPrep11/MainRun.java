package org.example.Practice.Practice9.FinalPrep11;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Year;
import java.time.ZoneId;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

enum VehicleType{
    SEDAN, TRUCK, COUPE, SUV
}
enum FuelType{
    GASOLINE, DIESEL, ELECTRIC, HYBRID
}
enum VehicleStatus{
    ACTIVE, INACTIVE, UNDER_MAINTENANCE, SOLD
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface VehicleInfo{
    VehicleType vehicle_type() default VehicleType.SEDAN;
    FuelType fuel_type() default FuelType.GASOLINE;
}
class Vehicle{
    @VehicleInfo(vehicle_type = VehicleType.SEDAN)
    private String vehicleId;
    @VehicleInfo(vehicle_type = VehicleType.SEDAN)
    private String vehicleName;
    private VehicleType vehicleType;
    private FuelType fuelType;
    private VehicleStatus vehicleStatus;
    private double engineCapacity;
    private int mileage;
    private int manufacturingYear;
    private LocalDate lastServiced;
    private boolean isElectric;
    private char vehicleRank;
    private int vehicleAge;

    public int getVehicleAge() {
        return vehicleAge;
    }

    public char getVehicleRank() {
        return vehicleRank;
    }

    public boolean isElectric() {
        return isElectric;
    }

    public LocalDate getLastServices() {
        return lastServiced;
    }

    public int getManufacturingYear() {
        return manufacturingYear;
    }

    public int getMileage() {
        return mileage;
    }

    public double getEngineCapacity() {
        return engineCapacity;
    }

    public VehicleStatus getVehicleStatus() {
        return vehicleStatus;
    }

    public FuelType getFuelType() {
        return fuelType;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public Vehicle(VehicleBuilder builder){
        this.vehicleId=builder.vehicleId;
        this.vehicleName=builder.vehicleName;
        this.vehicleType=builder.vehicleType;
        this.fuelType=builder.fuelType;
        this.vehicleStatus=builder.vehicleStatus;
        this.engineCapacity=builder.engineCapacity;
        this.mileage=builder.mileage;
        this.manufacturingYear=builder.manufacturingYear;
        this.lastServiced=builder.lastServiced;
        this.isElectric=builder.isElectric;
        this.vehicleRank=builder.vehicleRank;
        this.vehicleAge=builder.vehicleAge;

    }
    public static class VehicleBuilder{
        private String vehicleId;
        private String vehicleName;
        private VehicleType vehicleType;
        private FuelType fuelType;
        private VehicleStatus vehicleStatus;
        private double engineCapacity;
        private int mileage;
        private int manufacturingYear;
        private LocalDate lastServiced;
        private boolean isElectric;
        private char vehicleRank;
        private int vehicleAge;

        public VehicleBuilder(String vehicleId, VehicleType vehicleType, double engineCapacity, int vehicleAge){
            this.vehicleId=vehicleId;
            this.vehicleType=vehicleType;
            this.engineCapacity=engineCapacity;
        }
        public VehicleBuilder setVehicleId(String vehicleId){
            this.vehicleId=vehicleId;
            return this;
        }
        public VehicleBuilder setVehicleName(String vehicleName){
            this.vehicleName=vehicleName;
            return this;
        }
        public VehicleBuilder setVehicleType(VehicleType vehicleType){
            this.vehicleType=vehicleType;
            return this;
        }
        public VehicleBuilder setFuelType(FuelType fuelType){
            this.fuelType=fuelType;
            return this;
        }
        public VehicleBuilder setVehicleStatus(VehicleStatus vehicleStatus){
            this.vehicleStatus=vehicleStatus;
            return this;
        }
        public VehicleBuilder setEngineCapacity(double engineCapacity){
            this.engineCapacity=engineCapacity;
            return this;
        }
        public VehicleBuilder setMileage(int mileage){
            this.mileage=mileage;
            return this;
        }
        public VehicleBuilder setManufacturingYear(int manufacturingYear){
            this.manufacturingYear=manufacturingYear;
            return this;
        }
        public VehicleBuilder setLastServiced(LocalDate lastServiced){
            this.lastServiced=lastServiced;
            return this;
        }
        public VehicleBuilder setIsElectric(boolean isElectric){
            this.isElectric=isElectric;
            return this;
        }
        public VehicleBuilder setVehicleRank(char vehicleRank){
            this.vehicleRank=vehicleRank;
            return this;
        }
        public VehicleBuilder setVehicleAge(int vehicleAge){
            this.vehicleAge=vehicleAge;
            return this;
        }
        public Vehicle build(){
            return new Vehicle(this);
        }
    }
}
class InvalidVehicleDataException extends RuntimeException{
    public InvalidVehicleDataException(String message){
        super(message);
    }
    public InvalidVehicleDataException(String message, Throwable cause){
        super(message, cause);
    }
}
class VehicleSetup{
    public static List<Vehicle> loadVehicles(String fileName){
        List<Vehicle> vehicles=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine();
            if(line==null){
                throw new InvalidVehicleDataException("The file is empty");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");

                String engineCapacityStr=fields[5].isEmpty() ? "1.5" : fields[5];
                double engineCapacity=Double.parseDouble(engineCapacityStr);

                String vehicleTypeStr=fields[2].isEmpty() ? "SEDAN" : fields[2].toUpperCase();
                VehicleType vehicleType=VehicleType.valueOf(vehicleTypeStr);

                int mileage;
                String mileageStr=fields[6].trim();
                if(!mileageStr.isEmpty() && mileageStr.matches("\\d++")){
                    mileage=Integer.parseInt(mileageStr);
                }else{
                    mileage=0;
                }

                String vehicleStatusStr=fields[4].isEmpty() ? "ACTIVE" : fields[4].toUpperCase();
                VehicleStatus vehicleStatus=VehicleStatus.valueOf(vehicleStatusStr);

                boolean isElectric;
                String isElectricStr=fields[10].trim();
                if(!isElectricStr.isEmpty() && isElectricStr.equalsIgnoreCase("true")){
                    isElectric=true;
                }else if(!isElectricStr.isEmpty() && isElectricStr.equalsIgnoreCase("false")){
                    isElectric=false;
                }else {
                    isElectric = false;
                }
                char vehicleRank='C';
                String vehicleRankStr=fields[11].trim();
                if(!vehicleRankStr.isEmpty() && vehicleRankStr.matches("[A-F]") && vehicleRankStr.length()==1){
                    vehicleRank=vehicleRankStr.charAt(0);
                }
                int manufacturingYear=Integer.parseInt(fields[8]);
                int currentYear= Year.now().getValue();
                int vehicleAge=currentYear-manufacturingYear;

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                String lastServicedStr = fields[9].trim();
                LocalDate lastServiced = Optional.ofNullable(lastServicedStr)
                        .filter(s -> !s.isEmpty())
                        .map(s -> {
                            try {
                                return sdf.parse(s).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                            } catch (Exception e) {
                                return null; // Return null if parsing fails
                            }
                        })
                        .orElse(LocalDate.now()); // Default to current date if parsing fails

                vehicles.add(new Vehicle.VehicleBuilder(fields[0],vehicleType, engineCapacity, vehicleAge)
                        .setVehicleId(fields[0])
                        .setVehicleName(fields[1])
                        .setVehicleType(vehicleType)
                        .setFuelType(FuelType.valueOf(fields[3]))
                        .setVehicleStatus(VehicleStatus.valueOf(fields[4]))
                        .setEngineCapacity(engineCapacity)
                        .setMileage(mileage)
                        .setManufacturingYear(manufacturingYear)
                        .setLastServiced(lastServiced)
                        .setIsElectric(isElectric)
                        .setVehicleRank(vehicleRank)
                        .setVehicleAge(vehicleAge)
                        .build()
                );


            }

        }catch(IOException e){
            throw new InvalidVehicleDataException("Error loading the file", e);
        }
        return vehicles;
    }
}

class VehicleReportGenerator{
    public static void generateReport(String outputFileName, List<Vehicle> vehicles){
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName))){
            writer.write("vehicleId,vehicleName,vehicleType,fuelType,vehicleStatus,engineCapacity,mileage,manufacturingYear,lastServiced,isElectric,vehicleRank,vehicleAge\n");
            for(Vehicle vehicle : vehicles){
                StringBuilder line=new StringBuilder();
                Field[] fields=Vehicle.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(vehicle);
                    VehicleInfo vehicleInfo=field.getAnnotation(VehicleInfo.class);
                    if(vehicleInfo!=null){
                        if(value instanceof String){
                            String valueStr=(String) value;
                            switch(vehicleInfo.vehicle_type()){
                                case SEDAN:
                                    value=valueStr.toLowerCase();
                                    break;
                                case SUV:
                                    break;
                                case TRUCK:
                                    value=valueStr.toUpperCase();
                                default:
                                    break;
                            }
                        }
                        if(value instanceof Integer){
                            if(vehicleInfo.fuel_type()==FuelType.GASOLINE){
                                value=value.toString()+"!";
                            }
                            if(vehicleInfo.fuel_type()==FuelType.ELECTRIC){
                                value="Electric";
                            }
                        }
                    }
                    line.append(value);
                    if(field!=fields[fields.length-1]){
                        line.append(",");
                    }
                }
                writer.write(line.toString()+"\n");
            }

        }catch(IOException e){
            e.printStackTrace();
        }catch(IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }
}

class vehicleTest{
    static List<Vehicle> vehicles;
    @BeforeEach
    void setUp(){
        String CSVTest="C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep11\\vehicles.csv";
        vehicles=VehicleSetup.loadVehicles(CSVTest);
    }
    @Test
    void ifValuesEmpty_ThrowCustomException(){
        String faultyCSV="vehicleId, vehicleFuel, age";
        assertThrows(InvalidVehicleDataException.class, ()->VehicleSetup.loadVehicles(faultyCSV));
    }
}


public class MainRun {
    public static void main(String[] args) {

    }
}
