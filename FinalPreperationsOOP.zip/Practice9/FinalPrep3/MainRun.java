package org.example.Practice.Practice9.FinalPrep3;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

enum CaseFormatter{
    ORDINARY, UPPER_CASE, LOWER_CASE;
}
enum NumberFormatter{
    COMMA, PERCENTAGE;
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface WriteConcerns{
    CaseFormatter case_format() default CaseFormatter.ORDINARY;
    NumberFormatter number_format() default NumberFormatter.COMMA;
}

class Book{
    @WriteConcerns
    private Date releaseDate;
    @WriteConcerns(case_format=CaseFormatter.ORDINARY)
    private String quarter;
    private int qtr;
    private int year;
    @WriteConcerns(case_format=CaseFormatter.UPPER_CASE)
    private String customerId;
    @WriteConcerns(number_format=NumberFormatter.COMMA)
    private double totalAmount;
    @WriteConcerns(number_format=NumberFormatter.PERCENTAGE)
    private double profitPercentage;
    private double profitInr;
    private double costPrice;

    public Date getReleaseDate(){
        return releaseDate;
    }
    public String getQuarter(){
        return quarter;
    }
    public int getQtr(){
        return qtr;
    }
    public int getYear(){
        return year;
    }
    public String getCustomerId(){
        return customerId;
    }
    public double getTotalAmount(){
        return totalAmount;
    }
    public double getProfitPercentage(){
        return profitPercentage;
    }
    public double getProfitInr(){
        return profitInr;
    }
    private double getCostPrice(){
        return costPrice;
    }
    public Book(BookBuilder builder){
        this.releaseDate=builder.releaseDate;
        this.quarter=builder.quarter;
        this.qtr=builder.qtr;
        this.year=builder.year;
        this.customerId=builder.customerId;
        this.totalAmount=builder.totalAmount;
        this.profitPercentage=builder.profitPercentage;
        this.profitInr=builder.profitInr;
        this.costPrice=builder.costPrice;
    }

    public static class BookBuilder{
        private Date releaseDate;
        private String quarter;
        private int qtr;
        private int year;
        private String customerId;
        private double totalAmount;
        private double profitPercentage;
        private double profitInr;
        private double costPrice;
        public BookBuilder(){}

        public BookBuilder setReleaseDate(Date releaseDate){
            this.releaseDate=releaseDate;
            return this;
        }
        public BookBuilder setQuarter(String quarter){
            this.quarter=quarter;
            return this;
        }
        public BookBuilder setQtr(int qtr){
            this.qtr=qtr;
            return this;
        }
        public BookBuilder setYear(int year){
            this.year=year;
            return this;
        }
        public BookBuilder setCustomerId(String customerId){
            this.customerId=customerId;
            return this;
        }
        public BookBuilder setTotalAmount(double totalAmount){
            this.totalAmount=totalAmount;
            return this;
        }
        public BookBuilder setProfitPercentage(double profitPercentage){
            this.profitPercentage=profitPercentage;
            return this;
        }
        public BookBuilder setProfitInr(double profitInr){
            this.profitInr=profitInr;
            return this;
        }
        public BookBuilder setCostPrice(double costPrice){
            this.costPrice=costPrice;
            return this;
        }
        public Book build(){
            return new Book(this);
        }

    }
}
class WrongFormatException extends RuntimeException{
    public WrongFormatException(String message){
        throw new WrongFormatException(message);
    }
    public WrongFormatException(String message, Throwable cause){
        throw new WrongFormatException(message, cause);
    }
}
class FinalPrep{
    public static List<Book> loadBooks(String fileName){
        List<Book> books=new ArrayList<>();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        int LineNumber=0;
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine(); //Skip header
            if((line==null)){
                throw new WrongFormatException("The csv file is empty");
            }
            while((line=reader.readLine())!=null){
                LineNumber++;
                String fields[]=line.split(",");
                if(fields[0].isEmpty()|fields[2].isEmpty()){
                    throw new WrongFormatException("Values are emoty", new ClassCastException());
                }
                books.add(new Book.BookBuilder()
                        .setReleaseDate(sdf.parse(fields[0]))
                        .setQuarter(fields[1])
                        .setQtr(Integer.parseInt(fields[2]))
                        .setYear(Integer.parseInt(fields[3]))
                        .setCustomerId(fields[4])
                        .setTotalAmount(Double.parseDouble(fields[5]))
                        .setProfitPercentage(Double.parseDouble(fields[6]))
                        .setProfitInr(Double.parseDouble(fields[7]))
                        .setCostPrice(Double.parseDouble(fields[8]))
                        .build());
            }
        }catch(IOException | ParseException e){
            throw new WrongFormatException("Error reading the file", e);

        }
        return books;
    }
}

public class MainRun {
    public static void main(String[] args) {
        String fileName="books.csv";
        List<Book> books=FinalPrep.loadBooks(fileName);

    }
}
