package org.example.Practice.Practice9.FinalPrep1;
import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

enum CaseFormatter{
    ORDINARY, UPPER_CASE, LOWER_CASE
}
enum NumberFormatter{
    COMMA, PERCENTAGE
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface WriteConcerns{
    CaseFormatter case_format() default CaseFormatter.ORDINARY;
    NumberFormatter number_format() default NumberFormatter.COMMA;
}
class Book{
    @WriteConcerns
    private Date date;
    @WriteConcerns(case_format = CaseFormatter.ORDINARY)
    private String quarter;
    @WriteConcerns(case_format=CaseFormatter.UPPER_CASE)
    private String customerId;
    private int qtr;
    private int year;
    @WriteConcerns(number_format=NumberFormatter.COMMA)
    private double totalAmount;
    @WriteConcerns(number_format =NumberFormatter.PERCENTAGE)
    private double profitPercentage;
    private double profitInr;
    private double costPrice;

    public Date getDate(){
        return date;
    }
    public String getQuarter(){
        return quarter;
    }
    public int getQtr(){
        return qtr;
    }
    public int getYear(){
        return year;
    }
    public double getTotalAmount(){
        return totalAmount;
    }
    public double getProfitPercentage(){
        return profitPercentage;
    }
    public double getProfitInr(){
        return profitInr;
    }
    public double getCostPrice(){
        return costPrice;
    }
    public String getCustomerId(){
        return customerId;
    }

    public Book(BookBuilder builder){
       this.date=builder.date;
       this.quarter=builder.quarter;
       this.qtr=builder.qtr;
       this.year=builder.year;
       this.customerId=builder.customerId;
       this.totalAmount=builder.totalAmount;
       this.profitPercentage=builder.profitPercentage;
       this.profitInr=builder.profitInr;
       this.costPrice=builder.costPrice;

    }

    public static class BookBuilder{
        private Date date;
        private String quarter;
        private int qtr;
        private int year;
        private String customerId;
        private double totalAmount;
        private double profitPercentage;
        private double profitInr;
        private double costPrice;

        public BookBuilder(){}

        public BookBuilder setDate(Date date){
            this.date=date;
            return this;
        }
        public BookBuilder setQuarter(String quarter){
            this.quarter=quarter;
            return this;
        }
        public BookBuilder setQtr(int qtr){
            this.qtr=qtr;
            return this;
        }
        public BookBuilder setYear(int year){
            this.year=year;
            return this;
        }
        public BookBuilder setCustomerId(String customerId){
            this.customerId=customerId;
            return this;
        }
        public BookBuilder setTotalAmount(double totalAmount){
            this.totalAmount=totalAmount;
            return this;
        }
        public BookBuilder setProfitPercentage(double profitPercentage){
            this.profitPercentage=profitPercentage;
            return this;
        }
        public BookBuilder setProfitInr(double profitInr){
            this.profitInr=profitInr;
            return this;
        }
        public BookBuilder setCostPrice(double costPrice){
            this.costPrice=costPrice;
            return this;
        }
        public Book build(){
            return new Book(this);
        }
    }

}
class WrongFormatException extends RuntimeException{
    public WrongFormatException(String message){
        super(message);
    }
    public WrongFormatException(String message, Throwable cause){
        super(message, cause);
    }
}

class FinalPrep{
    private List<Book> books;
    public FinalPrep(String filename){
        this.books=loadBooks(filename);
    }
    public static List<Book> loadBooks(String filename){
        List<Book> bookList=new ArrayList<>();
        try{
            BufferedReader reader=new BufferedReader(new FileReader(filename));
            List<String> lines=reader.lines().collect(Collectors.toList());

            for(int i=1; i<lines.size();i++){
                String[] parts=lines.get(i).split(";");
                if(parts[0] == ""||parts[4] == ""){
                    throw new WrongFormatException("Values are empty", new ClassCastException());
                }
                bookList.add(
                        new Book.BookBuilder()
                                .setDate(new SimpleDateFormat("MM/dd/yyyy").parse(parts[0]))
                                .setQuarter(parts[1]=="" ? null : parts[1])
                                .setQtr(Integer.parseInt(parts[2]))
                                .setYear(Integer.parseInt(parts[3]))
                                .setCustomerId(parts[4])
                                .setTotalAmount(Double.parseDouble(parts[5]))
                                .setProfitPercentage(Double.parseDouble(parts[6]))
                                .setCostPrice(Double.parseDouble(parts[7]))
                                .build()
                );
            }
        }catch(FileNotFoundException e){
            throw new RuntimeException(e);
        }catch(ParseException ee){
            ee.printStackTrace();
        }
        return bookList;
    }
    public List<Book> getBooks() {
        return this.books;
    }
}
class ReportWriter{
    public static void writeReport(String outputFileName, List<Book> books){
        Class c1=Book.class;
        Field[] fields=c1.getDeclaredFields();
        try{
            BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName));
            for(int i=0;i<fields.length;i++){
                writer.write(i==fields.length-1 ?
                        fields[i].getName().concat("\n"):
                        fields[i].getName().concat("\n"));
            }

            for(Book book : books){
                for(int i=0; i<fields.length;i++){
                    fields[i].setAccessible(true);
                    if(fields[i].isAnnotationPresent(WriteConcerns.class)){
                        if(fields[i].get(book) instanceof String){
                            CaseFormatter format=fields[i].getAnnotation(WriteConcerns.class).case_format();
                            switch(format){
                                case UPPER_CASE ->writer.write(
                                        i==fields.length-1 ?
                                                fields[i].get(book).toString().toUpperCase().concat("\n"):
                                                fields[i].get(book).toString().toUpperCase().concat(";")
                                );
                                case LOWER_CASE -> writer.write(
                                        i==fields.length-1 ?
                                                fields[i].get(book).toString().toLowerCase().concat("\n"):
                                                fields[i].get(book).toString().toLowerCase().concat(";")
                                        );
                                case ORDINARY -> writer.write(
                                        i==fields.length-1 ?
                                                fields[i].get(book).toString().concat("\n"):
                                                fields[i].get(book).toString().concat(";")
                                );
                            }
                        }else{
                            NumberFormatter format=fields[i].getAnnotation(WriteConcerns.class).number_format();
                            if(format==NumberFormatter.COMMA){
                                DecimalFormat df=new DecimalFormat("#,###.##");
                                writer.write(i==fields.length-1 ?
                                        df.format(fields[i].get(book)).concat("\n"):
                                        df.format(fields[i].get(book)).concat(";")
                                );
                            }else{
                                writer.write(
                                        i==fields.length-1 ?
                                                fields[i].get(book).toString().concat("%\n"):
                                                fields[i].get(book).toString().concat("%;")
                                );
                            }
                        }
                    }else{
                        writer.write(
                                  i==fields.length-1 ?
                                          fields[i].get(book).toString().concat("\n"):
                                          fields[i].get(book).toString().concat(";")
                        );
                    }
                }
            }
            writer.close();
        }catch(IOException| IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }
}

public class MainRun {
    public static void main(String[] args) {
        FinalPrep prep = new FinalPrep("mybooks.csv");
        ReportWriter writer = new ReportWriter();
        writer.writeReport("tmp.csv", prep.getBooks());
    }
}




