package org.example.Practice.Practice9.FinalPrep6;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

enum CaseFormatter{
    ORDINARY, UPPER_CASE, LOWER_CASE
}
enum NumberFormatter{
    COMMA, PERCENTAGE
}
enum Genre{
    FICTION, NON_FICTION, SCIENCE, FANTASY, HISTORY, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface WriteConcerns{
    CaseFormatter case_format() default CaseFormatter.ORDINARY;
    NumberFormatter number_format() default NumberFormatter.COMMA;
}
class Book{
    @WriteConcerns
    private Date date;
    @WriteConcerns(case_format=CaseFormatter.ORDINARY)
    private String quarter;
    private int qtr;
    private int year;
    @WriteConcerns(case_format=CaseFormatter.UPPER_CASE)
    private String customerId;
    @WriteConcerns(number_format=NumberFormatter.COMMA)
    private double totalAmount;
    @WriteConcerns(number_format=NumberFormatter.PERCENTAGE)
    private double profitPercentage;
    private double profitInr;
    private double costPrice;
    private Genre genre;
    private int awards;

    public String getCustomerId() {
        return customerId;
    }

    public Book(BookBuilder builder){
        this.date=builder.date;
        this.quarter=builder.quarter;
        this.qtr=builder.qtr;
        this.year=builder.year;
        this.customerId=builder.customerId;
        this.profitPercentage=builder.profitPercentage;
        this.profitInr=builder.profitInr;
        this.costPrice=builder.costPrice;
        this.genre=builder.genre;
        this.awards=builder.awards;

    }
    public static class BookBuilder{
        public BookBuilder(String quarter, double costPrice){
            this.quarter=quarter;
            this.costPrice=costPrice;
        }
        private Date date;
        private String quarter;
        private int qtr;
        private int year;
        private String customerId;
        private double totalAmount;
        private double profitPercentage;
        private double profitInr;
        private double costPrice;
        private Genre genre;
        private int awards;


        public BookBuilder setDate(Date date){
            this.date=date;
            return this;
        }
        public BookBuilder setQuarter(String quarter){
            this.quarter=quarter;
            return this;
        }
        public BookBuilder setQtr(int qtr){
            this.qtr=qtr;
            return this;
        }
        public BookBuilder setYear(int year){
            this.year=year;
            return this;
        }
        public BookBuilder setCustomerId(String customerId){
            this.customerId=customerId;
            return this;
        }
        public BookBuilder setTotalAmount(double totalAmount){
            this.totalAmount=totalAmount;
            return this;
        }
        public BookBuilder setProfitPercentage(double profitPercentage){
            this.profitPercentage=profitPercentage;
            return this;
        }
        public BookBuilder setProfitInr(double profitInr){
            this.profitInr=profitInr;
            return this;
        }
        public BookBuilder setCostPrice(double costPrice){
            this.costPrice=costPrice;
            return this;
        }
        public BookBuilder setGenre(Genre genre){
            this.genre=genre;
            return this;
        }
        public BookBuilder setAwards(int awards){
            this.awards=awards;
            return this;
        }
        public Book build(){
            return new Book(this);
        }
    }
}
class WrongFormatException extends RuntimeException{
    public WrongFormatException(String message){
        super(message);
    }
    public WrongFormatException(String message, Throwable cause){
        super(message, cause);
    }
}

class FinalPrep {
     public static List<Book> loadBooks(String fileName) {
         List<Book> books=new ArrayList<>();
         try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
             SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
             String line=reader.readLine(); //skip header
             if(line==null){
                 throw new WrongFormatException("File is empty.");
             }
             while((line=reader.readLine())!=null){
                 String[] fields=line.split(",");
                 if(fields[0].isEmpty()||fields[4].isEmpty()){
                     throw new WrongFormatException("Values are empty", new ClassCastException());
                 }
                 String totalAmountStr=fields[5].isEmpty() ? "0.0" : fields[5];
                 String genreStr=fields[9].isEmpty() ? "UNKNOWN" : fields[9].toUpperCase();
                 Genre genre=Genre.valueOf(genreStr);

                 // Handle CostPrice parsing properly
                 double costPrice = 0;
                 try {
                     costPrice = Double.parseDouble(fields[8]);
                 } catch (NumberFormatException e) {
                     throw new WrongFormatException("Invalid number format for CostPrice: " + fields[8], e);
                 }


                 books.add(new Book.BookBuilder(fields[1],Double.valueOf(fields[8]))
                         .setDate(sdf.parse(fields[0]))
                         .setQuarter(fields[1])
                         .setQtr(Integer.parseInt(fields[2]))
                         .setYear(Integer.parseInt(fields[2]))
                         .setCustomerId(fields[4])
                         .setTotalAmount(Double.valueOf(totalAmountStr))
                         .setProfitPercentage(Double.parseDouble(fields[6]))
                         .setProfitInr(Double.parseDouble(fields[7]))
                         .setCostPrice(Double.parseDouble(fields[8]))
                         .setGenre(genre)
                         .setAwards(Integer.parseInt(fields[10]))
                         .build()
                 );
             }

         } catch (IOException e) {
             throw new WrongFormatException("Error loading the file", e);
         } catch (ParseException e) {
             throw new WrongFormatException("Date format error in file", e);
         }
         return books;
     }
     public static int numberOfRows(List<Book> books){
         return books.size();
     }
}
class ReportWriter {
     public static void writeReport(String outputFileName, List<Book> books) {
         try(BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName))) {
             writer.write("Date,Quarter,Qtr,Year,CustomerId,TotalAmount,ProfitPercentage,ProfitInr,CostPrice,Genre\n");
             for(Book book : books){
                 StringBuilder line=new StringBuilder();
                 Field[] fields=Book.class.getFields();
                 for(Field field : fields){
                     field.setAccessible(true);
                     Object value=field.get(book);
                     WriteConcerns writeConcerns=field.getAnnotation(WriteConcerns.class);
                     if(writeConcerns!=null){
                         if(value instanceof String){
                             String strValue=(String) value;
                             switch(writeConcerns.case_format()){
                                 case LOWER_CASE:
                                     value=strValue.toLowerCase();
                                     break;
                                 case UPPER_CASE:
                                     value=strValue.toUpperCase();
                                     break;
                                 case ORDINARY:
                                     break;
                                 default:
                                     break;
                             }
                         }
                     }
                     if(value instanceof Integer){
                         if(writeConcerns.number_format()==NumberFormatter.PERCENTAGE){
                             value=value.toString()+"%";
                         }
                         if(writeConcerns.number_format()==NumberFormatter.COMMA){
                             DecimalFormat df = new DecimalFormat("#,###.##");
                             value=df.format(value);
                         }

                     }
                     line.append(value);
                     if(field!=fields[fields.length-1]){
                         line.append(",");
                     }

                 }
                 writer.write(line.toString()+"\n");

             }
         } catch(IOException e) {
             e.printStackTrace();
         } catch (IllegalAccessException e) {
             throw new RuntimeException(e);
         }
     }
}

class BookTest{
    static List<Book> books;
    @BeforeEach
    void setUp(){
        books=FinalPrep.loadBooks("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep6\\books.csv");
    }

    @Test
    void ifValuesEmpty_ThrownAnCustomException(){
        String faultyCSV="Date,,customerId,profitInr,)";
        assertThrows(WrongFormatException.class, ()->FinalPrep.loadBooks(faultyCSV));
    }

    @Test
    void ifFileLoaded_assertMultipleConditions(){
        assertAll(
                ()->assertEquals("BO&FWVXXU",books.get(1).getCustomerId()),
                ()->assertEquals(books.size(),FinalPrep.numberOfRows(books))
        );
    }
    @Test
    void ifFileDoesNotExist_assertCauseIsFileNotFoundException(){
        String nonExistentFile = "non_existent_file.csv";
        RuntimeException thrownException=assertThrows(RuntimeException.class,
                ()->FinalPrep.loadBooks(nonExistentFile));
        assertTrue(thrownException.getCause() instanceof FileNotFoundException);
    }
}

public class MainRun {
     public static void main(String[] args) {
         // Logic for calling FinalPrep and ReportWriter goes here
         String inputFileName = "C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep6\\books.csv";   // Ensure this file exists
         String outputFileName = "Books_Report.csv";

         // Load books from the CSV file
         List<Book> books = FinalPrep.loadBooks(inputFileName);
         System.out.println("Books loaded successfully.");
         System.out.println("Number of books loaded: " + books.size());

         // Write the report to the output file
         ReportWriter.writeReport(outputFileName, books);
         System.out.println("Report generated successfully: " + outputFileName);

     }
}
