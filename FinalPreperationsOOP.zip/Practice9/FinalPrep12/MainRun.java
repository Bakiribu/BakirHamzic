package org.example.Practice.Practice9.FinalPrep12;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

enum InstructorStyle{
    FITNESS_EXPERT, NUTRITIONIST, WELLNESS_COACH
}
enum ClassFormat{
    IN_PERSON, ONLINE
}
enum ClassCategory{
    YOGA, PILATES, CARDIO, STRENGTH, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface FitnessClassFormat{
    InstructorStyle instructor_style() default InstructorStyle.FITNESS_EXPERT;
    ClassFormat class_format() default ClassFormat.IN_PERSON;
}

class FitnessClass{
    @FitnessClassFormat(instructor_style = InstructorStyle.FITNESS_EXPERT)
    private String classId;
    @FitnessClassFormat(instructor_style = InstructorStyle.FITNESS_EXPERT)
    private String classTitle;
    @FitnessClassFormat(instructor_style = InstructorStyle.FITNESS_EXPERT)
    private String instructorName;
    private ClassFormat classFormat;
    private ClassCategory classCategory;
    private int classDurationInMinutes;
    private int maxParticipants;
    private int currentParticipants;
    private boolean isAvailableOnline;
    private char classRank;

    public String getClassId() {
        return classId;
    }

    public String getClassTitle() {
        return classTitle;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public ClassFormat getClassFormat() {
        return classFormat;
    }

    public ClassCategory getClassCategory(){
        return classCategory;
    }

    public int getClassDurationInMinutes() {
        return classDurationInMinutes;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public int getCurrentParticipants() {
        return currentParticipants;
    }

    public boolean isAvailableOnline() {
        return isAvailableOnline;
    }

    public char getClassRank() {
        return classRank;
    }

    public FitnessClass(FitnessClassBuilder builder){
        this.classId=builder.classId;
        this.classTitle=builder.classTitle;
        this.instructorName=builder.instructorName;
        this.classFormat=builder.classFormat;
        this.classCategory=builder.classCategory;
        this.classDurationInMinutes=builder.classDurationInMinutes;
        this.maxParticipants=builder.maxParticipants;
        this.currentParticipants=builder.currentParticipants;
        this.isAvailableOnline=builder.isAvailableOnline;
        this.classRank=builder.classRank;
    }

    public static class FitnessClassBuilder{
        private String classId;
        private String classTitle;
        private String instructorName;
        private ClassFormat classFormat;
        private ClassCategory classCategory;
        private int classDurationInMinutes;
        private int maxParticipants;
        private int currentParticipants;
        private boolean isAvailableOnline;
        private char classRank;

        public FitnessClassBuilder(String classId, ClassCategory classCategory, int classDurationInMinutes){
            this.classId=classId;
            this.classCategory=classCategory;
            this.classDurationInMinutes=classDurationInMinutes;
        }
        public FitnessClassBuilder setClassId(String classId){
            this.classId=classId;
            return this;
        }
        public FitnessClassBuilder setClassTitle(String classTitle){
            this.classTitle=classTitle;
            return this;
        }
        public FitnessClassBuilder setInstructorName(String instructorName){
            this.instructorName=instructorName;
            return this;
        }
        public FitnessClassBuilder setClassFormat(ClassFormat classFormat){
            this.classFormat=classFormat;
            return this;
        }
        public FitnessClassBuilder setClassCategory(ClassCategory classCategory){
            this.classCategory=classCategory;
            return this;
        }
        public FitnessClassBuilder setClassDurationInMinutes(int classDurationInMinues){
            this.classDurationInMinutes=classDurationInMinutes;
            return this;
        }
        public FitnessClassBuilder setMaxParticipants(int maxParticipants){
            this.maxParticipants=maxParticipants;
            return this;
        }
        public FitnessClassBuilder setCurrentParticipants(int currentParticipants){
            this.currentParticipants=currentParticipants;
            return this;
        }
        public FitnessClassBuilder setIsAvailableOnline(boolean isAvailableOnline){
            this.isAvailableOnline=isAvailableOnline;
            return this;
        }
        public FitnessClassBuilder setClassRank(char classRank){
            this.classRank=classRank;
            return this;
        }
        public FitnessClass build(){
            return new FitnessClass(this);
        }

    }
}
class InvalidClassDataException extends RuntimeException{
    public InvalidClassDataException(String message){
        super(message);
    }
    public InvalidClassDataException(String message, Throwable cause){
        super(message, cause);
    }
}
class FitnessClassSetup{
    public static List<FitnessClass> loadClasses(String fileName){
        List<FitnessClass> classes=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine();
            if(line==null){
                throw new InvalidClassDataException("Teh file is empty.");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");
                if(fields[0].isEmpty()||fields[1].isEmpty()){
                    throw new InvalidClassDataException("Invalid class data", new ClassCastException());
                }
                String classDurationInMinutesStr=fields[5].isEmpty() ? "60" : fields[5];
                int classDurationInMinutes=Integer.parseInt(classDurationInMinutesStr);

                String classCategoryStr=fields[4].isEmpty() ? "UNKOWN" : fields[4].toUpperCase();
                ClassCategory classCategory=ClassCategory.valueOf(classCategoryStr);

                int maxParticipants;
                String maxParticipantsStr=fields[6].trim();
                if(!maxParticipantsStr.isEmpty() && maxParticipantsStr.matches("\\d+")){
                    maxParticipants=Integer.parseInt(maxParticipantsStr);
                }else{
                    maxParticipants=0;
                }

                int currentParticipants;
                String currentParticipantsStr=fields[7].trim();
                if(!currentParticipantsStr.isEmpty() && currentParticipantsStr.matches("\\d+")){
                    currentParticipants=Integer.parseInt(currentParticipantsStr);
                }else{
                    currentParticipants=0;
                }

                boolean isAvailable;
                String isAvailableStr=fields[8].trim();
                if(isAvailableStr.equalsIgnoreCase("true")){
                    isAvailable=true;
                }else if(isAvailableStr.equalsIgnoreCase("false")){
                    isAvailable=false;
                }else{
                    isAvailable=false;
                }

                char classRank='F';
                String classRankStr=fields[9].trim();
                if(!classRankStr.isEmpty() && classRankStr.matches("[A-F]") && classRankStr.length()==1){
                    classRank=classRankStr.charAt(0);
                }
                classes.add(new FitnessClass.FitnessClassBuilder(fields[0],classCategory,classDurationInMinutes)
                        .setClassId(fields[0])
                        .setClassTitle(fields[1])
                        .setInstructorName(fields[2])
                        .setClassFormat(ClassFormat.valueOf(fields[3]))
                        .setClassCategory(classCategory)
                        .setClassDurationInMinutes(classDurationInMinutes)
                        .setMaxParticipants(maxParticipants)
                        .setCurrentParticipants(currentParticipants)
                        .setIsAvailableOnline(isAvailable)
                        .setClassRank(classRank)
                        .build()
                );

            }

        }catch(IOException e){
            throw new InvalidClassDataException("Error loading the file.",e);
        }
        return classes;
    }
    public static int getRows(List<FitnessClass> classes){
        return classes.size();
    }
}
class ReportGenerator{
    public static void generateReport(String outputFileName, List<FitnessClass> classes){
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName))){
            writer.write("classId,classTitle,instructorName,classFormat,classCategory,classDurationInMinutes,maxParticipants,currentParticipants,isAvailableOnline,classRank\n");
            for(FitnessClass fitnessClass : classes){
                StringBuilder line=new StringBuilder();
                Field[] fields=FitnessClass.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(fitnessClass);
                    FitnessClassFormat fitnessClassFormat=field.getAnnotation(FitnessClassFormat.class);
                    if(fitnessClassFormat!=null){
                        if(value instanceof String){
                            String valueStr=(String) value;
                            switch(fitnessClassFormat.instructor_style()){
                                case FITNESS_EXPERT:
                                    break;
                                case NUTRITIONIST:
                                    value= valueStr.toLowerCase();
                                    break;
                                case WELLNESS_COACH:
                                    value=valueStr.toLowerCase();
                                    break;
                                default:
                                    break;

                            }
                        }
                        if(value instanceof Integer){
                            if(fitnessClassFormat.class_format()==ClassFormat.IN_PERSON){
                                value=value.toString()+"!";
                            }
                            if(fitnessClassFormat.class_format()==ClassFormat.ONLINE){
                                value="Available online";
                            }
                        }
                    }
                    line.append(value);
                    if(field!=fields[fields.length-1]){
                        line.append(",");
                    }
                }
                writer.write(line.toString()+"\n");
            }
        }catch(IOException e){
            e.printStackTrace();
        }catch(IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }
}

class FitnessClassTest{
    static List<FitnessClass> classes;
    @BeforeEach
    void setUp(){
        String fileName="C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep12\\classes.csv";
        classes=FitnessClassSetup.loadClasses(fileName);
    }
    @Test
    void ifValuesEmpty_ThrowCustomException(){
        String faultyCSV="classId,classTitle,instructorName,classFormat,classCategory,classDurationInMinutes";
        assertThrows(InvalidClassDataException.class,()->FitnessClassSetup.loadClasses(faultyCSV));
    }
    @Test
    void ifFileLoaded_assertMultipleConditions(){
        String CSVFile="C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep12\\classes.csv";
        assertAll(
                        ()->assertEquals("F10001", classes.get(0).getClassId()),
                        ()->assertEquals(classes.size(),FitnessClassSetup.getRows(classes))
        );
    }
    @Test
    void ifFileDoesNotExist_assertCauseIsFileNotFoundException(){
        String nonExistentFile="random.csv";
        RuntimeException thrownException=assertThrows(RuntimeException.class,()->FitnessClassSetup.loadClasses(nonExistentFile));
        assertTrue(thrownException.getCause() instanceof FileNotFoundException);
    }
}


public class MainRun {
    public static void main(String[] args) {
        List<FitnessClass> classes= FitnessClassSetup.loadClasses("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep12\\classes.csv");
        System.out.println("Classes loaded successfully.");
        System.out.println("Number of classes loaded: " + classes.size());

        File dataFile = new File("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep12\\classes.csv");
        String reportDirectory = dataFile.getParent(); // Get the directory where the CSV is located
        String outputFileName = reportDirectory + File.separator + "classes_report.csv"; // Full path for the report

        ReportGenerator.generateReport(outputFileName, classes);

        String relativePath = "src/main/resources/classes.csv"; // Or adjust based on your actual path
        ReportGenerator.generateReport(relativePath, classes);

    }
}
