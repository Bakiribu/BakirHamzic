package org.example.Practice.Practice9.FinalPrep5;
import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

enum TextFormat{
    CAPITALIZE, LOWERCASE, PLAIN;
}
enum CurrencyFormat{
    USD, EURO, INR;
}
enum PaymentStatus{
    PAID, PENDING, OVERDUE;
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface FieldFormat{
    TextFormat text_format() default TextFormat.PLAIN;
    CurrencyFormat currency_format() default CurrencyFormat.USD;
}
class Invoice{
    @FieldFormat
    private Date invoiceDate;
    @FieldFormat(text_format=TextFormat.CAPITALIZE)
    private String invoiceNumber;
    private int qtr;
    private int year;
    @FieldFormat(text_format=TextFormat.CAPITALIZE)
    private String customerName;
    @FieldFormat(currency_format=CurrencyFormat.USD)
    private double totalAmount;
    @FieldFormat(currency_format=CurrencyFormat.EURO)
    private double taxAmount;
    private double netAmount;
    private PaymentStatus status;

    public Date getInvoiceDate(){
        return invoiceDate;
    }
    public String getInvoiceNumber(){
        return invoiceNumber;
    }
    public int getYear(){
        return year;
    }
    public int getQtr(){
        return qtr;
    }
    public String getCustomerName(){
        return customerName;
    }
    public double getTotalAmount(){
        return totalAmount;
    }
    public double getTaxAmount(){
        return taxAmount;
    }
    public double getNetAmount(){
        return netAmount;
    }
    public PaymentStatus getStatus(){
        return status;
    }
    public Invoice(InvoiceBuilder builder){
        this.invoiceDate=builder.invoiceDate;
        this.invoiceNumber=builder.invoiceNumber;
        this.qtr=builder.qtr;
        this.year=builder.year;
        this.customerName=builder.customerName;
        this.totalAmount=builder.totalAmount;
        this.taxAmount=builder.taxAmount;
        this.netAmount=builder.netAmount;


    }

    public static class InvoiceBuilder{
        private Date invoiceDate;
        private String invoiceNumber;
        private int qtr;
        private int year;
        private String customerName;
        private double totalAmount;
        private double taxAmount;
        private double netAmount;
        private PaymentStatus status;

        InvoiceBuilder(){}
        public InvoiceBuilder setInvoiceDate(Date invoiceDate){
            this.invoiceDate=invoiceDate;
            return this;
        }
        public InvoiceBuilder setInvoiceNumber(String invoiceNumber){
            this.invoiceNumber=invoiceNumber;
            return this;
        }
        public InvoiceBuilder setQtr(int qtr){
            this.qtr=qtr;
            return this;
        }
        public InvoiceBuilder setYear(int year){
            this.year=year;
            return this;
        }
        public InvoiceBuilder setCustomerName(String customerName){
            this.customerName=customerName;
            return this;
        }
        public InvoiceBuilder setTotalAmount(double totalAmount){
            this.totalAmount=totalAmount;
            return this;
        }
        public InvoiceBuilder setTaxAmount(double taxAmount){
            this.taxAmount=taxAmount;
            return this;
        }
        public InvoiceBuilder setNetAmount(double netAmount){
            this.netAmount=netAmount;
            return this;
        }
        public Invoice build(){
            return new Invoice(this);
        }
    }
}
class InvalidInvoiceException extends RuntimeException{
    public InvalidInvoiceException(String message){
        super(message);
    }
    public InvalidInvoiceException(String message, Throwable cause){
        super(message, cause);
    }
}
class InvoiceProcessor{
    public static List<Invoice> loadInvoices(String fileName){
        List<Invoice> invoices=new ArrayList<>();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine();
            if(line==null){
                throw new InvalidInvoiceException("File is empty");
            }
            while((line=reader.readLine())!=null){
                String fields[]=line.split(";");
                if(fields[0].isEmpty()||fields[1].isEmpty()||fields[5].isEmpty()){
                    throw new InvalidInvoiceException("Missing required field", new ClassCastException());
                }
                invoices.add(new Invoice.InvoiceBuilder()
                        .setInvoiceDate(sdf.parse(fields[0]))
                        .setInvoiceNumber(fields[1])
                        .setQtr(Integer.parseInt(fields[2]))
                        .setYear(Integer.parseInt(fields[3]))
                        .setCustomerName(fields[4])
                        .setTotalAmount(Double.parseDouble(fields[5]))
                        .setTaxAmount(Double.parseDouble(fields[6]))
                        .setNetAmount(Double.parseDouble(fields[7]))
                        .build());
            }
        }catch(IOException | ParseException e){
            throw new InvalidInvoiceException("Invalid data",e);

        }
        return invoices;
    }
}

public class MainRun {
    public static void main(String[] args) {
        String fileName="invoices.csv";
        List<Invoice> invoices=InvoiceProcessor.loadInvoices(fileName);


    }
}
