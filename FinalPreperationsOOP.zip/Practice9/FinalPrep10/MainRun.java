package org.example.Practice.Practice9.FinalPrep10;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

enum TextFormat{
    ORDINARY, UPPER_CASE, LOWER_CASE
}
enum ScoreFormat{
    COMMA, PERCENTAGE
}
enum RoleCategory{
    COMMANDER, PILOT, ENGINEER, SCIENTIST, MEDIC, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface DataFormat{
    TextFormat text_style() default TextFormat.ORDINARY;
    ScoreFormat score_style() default ScoreFormat.COMMA;
}
class CrewMember{
    @DataFormat(text_style = TextFormat.UPPER_CASE)
    private String crewId;
    @DataFormat(text_style = TextFormat.ORDINARY)
    private String name;
    @DataFormat(text_style = TextFormat.ORDINARY)
    private String realName;
    private int age;
    private RoleCategory roleCategory;
    @DataFormat(score_style = ScoreFormat.COMMA)
    private double missionSuccessRate;
    @DataFormat(score_style = ScoreFormat.PERCENTAGE)
    private double accuracy;
    private char ranking;
    private boolean eligiblePromotion;

    public String getName() {
        return name;
    }

    public String getCrewId() {
        return crewId;
    }

    public String getRealName() {
        return realName;
    }

    public int getAge() {
        return age;
    }

    public RoleCategory getRoleCategory() {
        return roleCategory;
    }

    public double getMissionSuccessRate() {
        return missionSuccessRate;
    }

    public double getAccuracy() {
        return accuracy;
    }

    public char getRanking() {
        return ranking;
    }

    public boolean isEligiblePromotion() {
        return eligiblePromotion;
    }

    public CrewMember(CrewMemberBuilder builder){
        crewId=builder.crewId;
        name=builder.name;
        realName=builder.realName;
        age=builder.age;
        roleCategory=builder.roleCategory;
        missionSuccessRate=builder.missionSuccessRate;
        accuracy=builder.accuracy;
        ranking=builder.ranking;
        eligiblePromotion=builder.eligiblePromotion;


    }
    public static class CrewMemberBuilder{
        private String crewId;
        private String name;
        private String realName;
        private int age;
        private RoleCategory roleCategory;
        private double missionSuccessRate;
        private double accuracy;
        private char ranking;
        private boolean eligiblePromotion;
        public CrewMemberBuilder(String crewId, RoleCategory roleCategory){
            this.crewId=crewId;
            this.roleCategory=roleCategory;
        }
        public CrewMemberBuilder setCrewId(String crewId){
            this.crewId=crewId;
            return this;
        }
        public CrewMemberBuilder setName(String name){
            this.name=name;
            return this;
        }
        public CrewMemberBuilder setAge(int age){
            this.age=age;
            return this;
        }
        public CrewMemberBuilder setRealName(String realName){
            this.realName=realName;
            return this;
        }
        public CrewMemberBuilder setRoleCategory(RoleCategory roleCategory){
            this.roleCategory=roleCategory;
            return this;
        }
        public CrewMemberBuilder setMissionSuccessRate(double missionSuccessRate){
            this.missionSuccessRate=missionSuccessRate;
            return this;
        }
        public CrewMemberBuilder setAccuracy(double accuracy){
            this.accuracy=accuracy;
            return this;
        }
        public CrewMemberBuilder setRanking(char ranking){
            this.ranking=ranking;
            return this;
        }
        public CrewMemberBuilder setEligiblePromotion(boolean eligiblePromotion){
            this.eligiblePromotion=eligiblePromotion;
            return this;
        }
        public CrewMember build(){
            return new CrewMember(this);
        }


    }
}

class InvalidDataException extends RuntimeException{
    public InvalidDataException(String message){
        super(message);
    }
    public InvalidDataException(String message, Throwable cause){
        super(message, cause);
    }
}
class ExpeditionSetup{
    public static List<CrewMember> loadCrewMembers(String fileName){
        List<CrewMember> members=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine(); //Skip header
            if(line==null){
                throw new InvalidDataException("The file is empty");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");
                if(fields[0].isEmpty()||fields[1].isEmpty()){
                    throw new InvalidDataException("Invalid crew member data", new ClassCastException());
                }
                String missionSuccessRateStr=fields[5].isEmpty() ? "0.0" : fields[5];
                double successRate=Double.parseDouble(fields[5]);

                String roleCategoryStr=fields[4].isEmpty() ? "UNKNOWN" : fields[4].toUpperCase();
                RoleCategory roleCategory=RoleCategory.valueOf(roleCategoryStr);
                String missionEligibleStr=fields[8].isEmpty() ? "false" : fields[8];
                boolean missionEligible=Boolean.parseBoolean(missionEligibleStr);

                String ageStr=fields[3].trim();
                int age;
                if(!ageStr.isEmpty()&&ageStr.matches("\\d+")){
                    age=Integer.parseInt(ageStr);
                    if(age<=18){
                        throw new InvalidDataException("Invalid age");
                    }
                }else{
                    throw new InvalidDataException("Invalid age");
                }
                double accuracy=0.0;
                try{
                    accuracy=Double.parseDouble(fields[6]);
                    if(accuracy<0||accuracy>100){
                        accuracy=0.0;
                    }
                }catch(NumberFormatException e){
                    accuracy=0.0;
                }

                char ranking='F';
                String charStr=fields[7].trim();
                if(!charStr.isEmpty() && charStr.matches("[A-F]")){
                    ranking=charStr.charAt(0);
                }else{
                    ranking='F';
                }

                boolean eligibleForPromotion;
                String eligiblePromotion=fields[8].trim();
                if(missionEligibleStr.equals("true")){
                    eligibleForPromotion=true;
                }else if(missionEligibleStr.matches("false")){
                    eligibleForPromotion=false;
                }else{
                    throw new InvalidDataException("Invalid promotion status");
                }

                members.add(new CrewMember.CrewMemberBuilder(fields[0], roleCategory)
                        .setCrewId(fields[0])
                        .setName(fields[1])
                        .setRealName(fields[2])
                        .setAge(age)
                        .setRoleCategory(roleCategory)
                        .setMissionSuccessRate(successRate)
                        .setAccuracy(accuracy)
                        .setRanking(ranking)
                        .setEligiblePromotion(eligibleForPromotion)
                        .build()
                );


            }


        }catch(IOException e){
            throw new InvalidDataException("Error loading the file", e);
        }
        return members;
    }
}
class ReportGenerator{
    public static void generateReport(String outputFileName, List<CrewMember> members){
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName))){
            writer.write("crewId,name,realName,age,roleCategory,missionSuccessRate,accuracy,ranking,eligibleForPromotion\n");
            for(CrewMember crewMember : members){
                StringBuilder line=new StringBuilder();
                Field[] fields=CrewMember.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(crewMember);
                    DataFormat dataFormat=field.getAnnotation(DataFormat.class);
                    if(dataFormat!=null){
                        if(value instanceof String){
                            String valueStr=(String) value;
                            switch(dataFormat.text_style()){
                                case LOWER_CASE:
                                    value=valueStr.toLowerCase();
                                    break;
                                case UPPER_CASE:
                                    value=valueStr.toUpperCase();
                                    break;
                                case ORDINARY:
                                    break;
                                default:
                                    break;

                            }
                        }
                        if(value instanceof Integer){
                            if(dataFormat.score_style()==ScoreFormat.PERCENTAGE){
                                value=value.toString()+"%";
                            }
                            if(dataFormat.score_style()==ScoreFormat.COMMA){
                                DecimalFormat df = new DecimalFormat("#,###.##");
                                value=df.format(value);
                            }
                        }
                    }
                    line.append(value);
                    if(field==fields[fields.length-1]){
                        line.append(",");
                    }

                }

                writer.write(line.toString()+"\n");
            }
        }catch(IOException e){
            e.printStackTrace();
        }catch(IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }
}

class ExpeditionTest{
    static List<CrewMember> members;
    @BeforeEach
    void setUp(){
        members=ExpeditionSetup.loadCrewMembers("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep10\\crew_data.csv");
    }

    @Test
    void ifValuesEmpty_ThrowCustomException(){
        String csvFile="weight,name,realName,age,,missionSuccessRate,accuracy,,eligibleForPromotion";
        assertThrows(InvalidDataException.class,()->ExpeditionSetup.loadCrewMembers(csvFile));


    }

}
public class MainRun {
    public static void main(String[] args) {

    }
}
