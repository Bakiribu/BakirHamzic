package org.example.Practice.Practice9.FinalPrep13;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

enum PerformanceType{
    SOLO, BAND, DJ
}
enum StageFormat{
    INDOOR, OUTDOOR
}
enum GenreCategory{
    ROCK, POP, ELECTRONIC, HIP_HOP, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface PerformanceFormat{
    PerformanceType performance_type() default PerformanceType.SOLO;
    StageFormat stage_format() default StageFormat.OUTDOOR;
}
class Artist{
    @PerformanceFormat(performance_type = PerformanceType.SOLO)
    private String artistId;
    @PerformanceFormat(performance_type = PerformanceType.SOLO)
    private String artistName;
    @PerformanceFormat(performance_type = PerformanceType.SOLO)
    private String performanceName;
    private StageFormat stageFormat;
    private GenreCategory genreCategory;
    private int performanceDurationInMinutes;
    private int maxAudienceCapacity;
    private int currentAudienceCapacity;
    private boolean isHeadLiner;
    private char performanceRating;

    public String getArtistId() {
        return artistId;
    }

    public String getArtistName() {
        return artistName;
    }

    public String getPerformanceName() {
        return performanceName;
    }

    public StageFormat getStageFormat() {
        return stageFormat;
    }

    public GenreCategory getGenreCategory() {
        return genreCategory;
    }

    public int getPerformanceDurationInMinutes() {
        return performanceDurationInMinutes;
    }

    public int getMaxAudienceCapacity() {
        return maxAudienceCapacity;
    }

    public int getCurrentAudienceCapacity() {
        return currentAudienceCapacity;
    }

    public boolean isHeadLiner() {
        return isHeadLiner;
    }

    public char getPerformanceRating() {
        return performanceRating;
    }

    public Artist(ArtistBuilder builder){
        this.artistId=builder.artistId;
        this.artistName=builder.artistName;
        this.performanceName=builder.performanceName;
        this.stageFormat=builder.stageFormat;
        this.performanceDurationInMinutes=builder.performanceDurationInMinutes;
        this.maxAudienceCapacity=builder.maxAudienceCapacity;
        this.currentAudienceCapacity=builder.currentAudienceCapacity;
        this.isHeadLiner=builder.isHeadLiner;
        this.performanceRating=builder.performanceRating;

    }
    public static class ArtistBuilder{
        private String artistId;
        private String artistName;
        private String performanceName;
        private StageFormat stageFormat;
        private GenreCategory genreCategory;
        private int performanceDurationInMinutes;
        private int maxAudienceCapacity;
        private int currentAudienceCapacity;
        private boolean isHeadLiner;
        private char performanceRating;

        public ArtistBuilder(String artistId, GenreCategory genreCategory, int performanceDurationInMinutes){
            this.artistId=artistId;
            this.genreCategory=genreCategory;
            this.performanceDurationInMinutes=performanceDurationInMinutes;
        }
        public ArtistBuilder setArtistId(String artistId){
            this.artistId=artistId;
            return this;
        }
        public ArtistBuilder setArtistName(String artistName){
            this.artistName=artistName;
            return this;
        }
        public ArtistBuilder setPerformanceName(String performanceName){
            this.performanceName=performanceName;
            return this;
        }
        public ArtistBuilder setStageFormat(StageFormat stageFormat){
            this.stageFormat=stageFormat;
            return this;
        }
        public ArtistBuilder setGenreCategory(GenreCategory genrecategory){
            this.genreCategory=genreCategory;
            return this;
        }
        public ArtistBuilder setPerformanceDurationInMinutes(int performanceDurationInMinutes){
            this.performanceDurationInMinutes=performanceDurationInMinutes;
            return this;
        }
        public ArtistBuilder setMaxAudienceCapacity(int maxAudienceCapacity){
            this.maxAudienceCapacity=maxAudienceCapacity;
            return this;
        }
        public ArtistBuilder setCurrentAudienceCapacity(int currentAudienceCapacity){
            this.currentAudienceCapacity=currentAudienceCapacity;
            return this;
        }
        public ArtistBuilder setIsHeadLiner(boolean isHeadLiner){
            this.isHeadLiner=isHeadLiner;
            return this;
        }
        public ArtistBuilder setPerformanceRating(char performanceRating){
            this.performanceRating=performanceRating;
            return this;
        }
        public Artist build(){
            return new Artist(this);
      }

    }
}
class InvalidArtistDataException extends RuntimeException{
    public InvalidArtistDataException(String message){
        super(message);
    }
    public InvalidArtistDataException(String message, Throwable cause){
        super(message, cause);
    }
}
class FestivalSetup{
    public static List<Artist> loadArtists(String fileName){
        List<Artist> artists=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine();
            if(line==null){
                throw new InvalidArtistDataException("Teh file is empty");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");
                if(fields[0].isEmpty()||fields[1].isEmpty()){
                    throw new InvalidArtistDataException("Invalid artist data", new ClassCastException());
                }
                String performanceDurationInMinutesStr=fields[5].isEmpty() ? "60" : fields[5];
                int performanceDurationInMinutes=Integer.parseInt(performanceDurationInMinutesStr);

                String genreCategoryStr=fields[4].isEmpty() ? "UNKNOWN" : fields[4].toUpperCase();
                GenreCategory genreCategory=GenreCategory.valueOf(genreCategoryStr);

                int maxAudienceCapacity;
                String maxAudienceCapacityStr=fields[6].trim();
                if(!maxAudienceCapacityStr.isEmpty() && maxAudienceCapacityStr.matches("\\d+")){
                    maxAudienceCapacity=Integer.parseInt(maxAudienceCapacityStr);
                }else{
                    maxAudienceCapacity=0;
                }

                int currentAudienceCount;
                String currentAudienceCountStr=fields[7].trim();
                if(!currentAudienceCountStr.isEmpty() && currentAudienceCountStr.matches("\\d+")){
                    currentAudienceCount=Integer.parseInt(currentAudienceCountStr);
                }else{
                    currentAudienceCount=0;
                }

                boolean isHeadLiner;
                String isHeadLinerStr=fields[8].trim();
                if(!isHeadLinerStr.isEmpty() && isHeadLinerStr.equalsIgnoreCase("true")){
                    isHeadLiner=true;
                }else if(!isHeadLinerStr.isEmpty() && isHeadLinerStr.equalsIgnoreCase("false")){
                    isHeadLiner=false;
                }else{
                    isHeadLiner=false;
                }

                char performanceRating='C';
                String performanceRatingStr=fields[9].trim();
                if(!performanceRatingStr.isEmpty() && performanceRatingStr.length()==1 && performanceRatingStr.matches("[A-F]")){
                    performanceRating=performanceRatingStr.charAt(0);
                }
                artists.add(new Artist.ArtistBuilder(fields[0], GenreCategory.valueOf(fields[4]),performanceDurationInMinutes)
                        .setArtistId(fields[0])
                        .setArtistName(fields[1])
                        .setPerformanceName(fields[2])
                        .setStageFormat(StageFormat.valueOf(fields[3]))
                        .setGenreCategory(genreCategory)
                        .setPerformanceDurationInMinutes(performanceDurationInMinutes)
                        .setMaxAudienceCapacity(maxAudienceCapacity)
                        .setCurrentAudienceCapacity(currentAudienceCount)
                        .setIsHeadLiner(isHeadLiner)
                        .setPerformanceRating(performanceRating)
                        .build()
                );

            }


        }catch(IOException e){
            throw new InvalidArtistDataException("Error loading the file",e);
        }
        return artists;
    }
}
class festivalReportGenerator{
    public static void generateReport(String outputFileName, List<Artist> artists){
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName))){
            writer.write("artistId,artistName,performanceName,stageFormat,genreCategory,performanceDurationInMinutes,maxAudienceCapacity,currentAudienceCount,isHeadliner,performanceRating\n");
            for(Artist artist : artists){
                StringBuilder line=new StringBuilder();
                Field[] fields=Artist.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(artist);
                    PerformanceFormat performanceFormat=field.getAnnotation(PerformanceFormat.class);
                    if(performanceFormat!=null){
                        if(value instanceof String){
                            String valueStr=(String) value;
                            switch(performanceFormat.performance_type()){
                                case SOLO:
                                    value=valueStr.toLowerCase();
                                    break;
                                case BAND:
                                    break;
                                case DJ:
                                    value=valueStr.toUpperCase();
                                    break;
                                default:
                                    break;

                            }
                        }
                        if(value instanceof Integer){
                            if(performanceFormat.stage_format()==StageFormat.INDOOR){
                                value=value.toString()+"!";
                            }
                            if(performanceFormat.stage_format()==StageFormat.OUTDOOR){
                                value="Outdoor stage";
                            }
                        }
                    }
                    line.append(value);
                    if(field!=fields[fields.length-1]){
                        line.append(",");
                    }
                }
                writer.write(line.toString()+"\n");
            }
        }catch(IOException e){
            e.printStackTrace();
        }catch(IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }
}
public class MainRun {
    public static void main(String[] args) {
        List<Artist> artists= FestivalSetup.loadArtists("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep13\\artists.csv");
        System.out.println("Artists loaded successfully.");
        System.out.println("Number of artists loaded: " + artists.size());

        File dataFile = new File("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep13\\artists.csv");
        String reportDirectory = dataFile.getParent(); // Get the directory where the CSV is located
        String outputFileName = reportDirectory + File.separator + "artists_report.csv"; // Full path for the report

        festivalReportGenerator.generateReport(outputFileName, artists);

        String relativePath = "src/main/resources/artists.csv"; // Or adjust based on your actual path
        festivalReportGenerator.generateReport(relativePath, artists);
    }
}
