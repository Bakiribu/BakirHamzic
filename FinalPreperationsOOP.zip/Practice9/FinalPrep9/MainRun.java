package org.example.Practice.Practice9.FinalPrep9;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

enum TextFormat{
    ORDINARY, UPPER_CASE, LOWER_CASE
}
enum ScoreFormat{
    COMMA, PERCENTAGE
}
enum GameCategory{
    FPS, MOBA, RPG, STRATEGY, SPORTS, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface DataFormat{
    TextFormat text_style() default TextFormat.ORDINARY;
    ScoreFormat score_style() default ScoreFormat.COMMA;
}

class Player{
    public String getPlayerId() {
        return playerId;
    }

    @DataFormat(text_style=TextFormat.UPPER_CASE)
    private String playerId;
    @DataFormat(text_style = TextFormat.ORDINARY)
    private String nickname;
    @DataFormat(text_style=TextFormat.ORDINARY)
    private String realName;
    private int age;
    private GameCategory gameCategory;
    @DataFormat(score_style=ScoreFormat.COMMA)
    private double winRate;
    @DataFormat(score_style=ScoreFormat.PERCENTAGE)
    private double accuracy;
    private char ranking;
    private boolean prizeEligible;

    public Player(PlayerBuilder builder){
        this.playerId=builder.playerId;
        this.nickname=builder.nickname;
        this.realName=builder.realName;
        this.age=builder.age;
        this.gameCategory=builder.gameCategory;
        this.winRate=builder.winRate;
        this.accuracy=builder.accuracy;
        this.ranking=builder.ranking;
        this.prizeEligible=builder.prizeEligible;

    }

    public static class PlayerBuilder{
        public PlayerBuilder(String playerId, GameCategory gameCategory){
            this.playerId=playerId;
            this.gameCategory=gameCategory;
        }
        private String playerId;
        private String nickname;
        private String realName;
        private int age;
        private GameCategory gameCategory;
        private double winRate;
        private double accuracy;
        private char ranking;
        private boolean prizeEligible;

        public PlayerBuilder setPlayerId(String playerId){
            this.playerId=playerId;
            return this;
        }
        public PlayerBuilder setNickname(String nickname){
            this.nickname=nickname;
            return this;
        }
        public PlayerBuilder setRealName(String realName){
            this.realName=realName;
            return this;
        }
        public PlayerBuilder setAge(int age){
            this.age=age;
            return this;
        }
        public PlayerBuilder setGameCategory(GameCategory gameCategory){
            this.gameCategory=gameCategory;
            return this;
        }
        public PlayerBuilder setWinRate(double winRate){
            this.winRate=winRate;
            return this;
        }
        public PlayerBuilder setAccuracy(double accuracy){
            this.accuracy=accuracy;
            return this;
        }
        public PlayerBuilder setRanking(char ranking){
            this.ranking=ranking;
            return this;
        }
        public PlayerBuilder setPrizeEligible(boolean prizeEligible){
            this.prizeEligible=prizeEligible;
            return this;
        }
        public Player build(){
            return new Player(this);
        }

    }
}

class InvalidDataException extends RuntimeException{
    public InvalidDataException(String message){
        super(message);
    }
    public InvalidDataException(String message, Throwable cause){
        super(message, cause);
    }
}
class TournamentSetup{
    public static List<Player> loadPlayers(String fileName){
        List<Player> players=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new FileReader(fileName))){
            String line=reader.readLine();
            if(line==null){
                throw new InvalidDataException("The file is empty");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");
                if(fields[0].isEmpty()||fields[1].isEmpty()){
                    throw new InvalidDataException("Invalid player data", new ClassCastException());
                }
                String winRateStr=fields[5].isEmpty() ? "0.0" : fields[5];
                String gameCategoryStr=fields[4].isEmpty() ? "UNKNOWN" : fields[4].toUpperCase();
                GameCategory gameCategory=GameCategory.valueOf(gameCategoryStr);
                String rankingStr=fields[7].isEmpty() ? "0" : fields[7];
                char ranking=rankingStr.charAt(0);

                players.add(new Player.PlayerBuilder(fields[0],gameCategory)
                        .setPlayerId(fields[0])
                        .setNickname(fields[1])
                        .setRealName(fields[2])
                        .setAge(Integer.parseInt(fields[3]))
                        .setGameCategory(gameCategory)
                        .setWinRate(Double.parseDouble(winRateStr))
                        .setAccuracy(Double.parseDouble(fields[6]))
                        .setRanking(ranking)
                        .setPrizeEligible(Boolean.parseBoolean(fields[8]))
                        .build()
                );
            }



        }catch(IOException e){
            throw new InvalidDataException("Error loading the file",e);
        }
        return players;
    }
    public static int numOfRows(List<Player> players){
        return players.size();
    }
}
class ReportGenerator{
    public static void generateReport(String outputFileName, List<Player> players){
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(outputFileName))){
            writer.write("playerId,nickname,realName,age,gameCategory,winRate,accuracy,ranking,prizeEligible\n");
            for(Player player : players){
                StringBuilder line=new StringBuilder();
                Field[] fields=Player.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(player);
                    DataFormat dataFormat=field.getAnnotation(DataFormat.class);
                    if(dataFormat!=null){
                        if(value instanceof String){
                            String stringVal=(String) value;
                            switch(dataFormat.text_style()){
                                case LOWER_CASE:
                                    value=stringVal.toLowerCase();
                                    break;
                                case UPPER_CASE:
                                    value=stringVal.toUpperCase();
                                    break;
                                case ORDINARY:
                                    break;
                                default:
                                    break;

                            }
                        }
                        if(value instanceof Integer){
                            if(dataFormat.score_style()==ScoreFormat.PERCENTAGE){
                                value=value.toString()+"%";
                            }
                            if(dataFormat.score_style()==ScoreFormat.COMMA){
                                DecimalFormat df = new DecimalFormat("#,###.##");
                                value=df.format(value);
                            }
                        }
                    }
                    line.append(value);
                    if(field!=fields[fields.length-1]){
                        line.append(",");
                    }
                }
                writer.write(line.toString()+"\n");
            }

        }catch(IOException e) {
            e.printStackTrace();
        }catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
class TournamentTest{
    static List<Player> players;
    @BeforeEach
    void setUp(){
        players=TournamentSetup.loadPlayers("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep9\\players.csv");
    }
    @Test
    void ifValuesEmpty_ThrowAnCustomException(){
        String faultyCSV="height,playerId,nickname,realName,age,gameCategory,winRate,accuracy,ranking,prizeEligible";
        assertThrows(InvalidDataException.class,()->TournamentSetup.loadPlayers(faultyCSV));
    }
    @Test
    void ifFileLoaded_assertMultipleConditions(){
        assertAll(
                ()->assertEquals("P10001",players.get(0).getPlayerId()),
                ()->assertEquals(players.size(),TournamentSetup.numOfRows(players))
        );
    }
    @Test
    void ifFileDoesNotExist_assertCauseIsFileNotFoundException(){
        String Non_existent_file="random.csv";
        RuntimeException thrownException=assertThrows(RuntimeException.class,
                ()->TournamentSetup.loadPlayers("random.csv"));
        assertTrue(thrownException.getCause() instanceof FileNotFoundException);
    }
}


public class MainRun {
    public static void main(String[] args) {
        List<Player> players=TournamentSetup.loadPlayers("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep9\\players.csv");
        System.out.println("Players loaded successfully.");
        System.out.println("Number of players loaded: " + players.size());

        File dataFile = new File("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep9\\players.csv");
        String reportDirectory = dataFile.getParent(); // Get the directory where the CSV is located
        String outputFileName = reportDirectory + File.separator + "players_report.csv"; // Full path for the report

        ReportGenerator.generateReport(outputFileName, players);

        String relativePath = "src/main/resources/player_report.csv"; // Or adjust based on your actual path
        ReportGenerator.generateReport(relativePath, players);
    }
}
