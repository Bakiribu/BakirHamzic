package org.example.Practice.Practice9.FinalPrep8;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

enum CaseFormatter{
    ORDINARY,UPPER_CASE, LOWER_CASE
}
enum NumberFormatter{
    COMMA, PERCENTAGE
}
enum Subject{
    MATH, SCIENCE, HISTORY, ENGLISH, ARTS, UNKNOWN
}
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface WriteConcerns{
    CaseFormatter case_format() default CaseFormatter.ORDINARY;
    NumberFormatter number_format() default NumberFormatter.COMMA;
}
class Student{
    public String getStudentId() {
        return studentId;
    }

    @WriteConcerns(case_format = CaseFormatter.UPPER_CASE)
    private String studentId;
    @WriteConcerns(case_format = CaseFormatter.ORDINARY)
    private String firstName;
    @WriteConcerns(case_format = CaseFormatter.ORDINARY)
    private String lastName;
    private int age;
    private Subject subject;
    @WriteConcerns(number_format = NumberFormatter.COMMA)
    private double examScore;
    @WriteConcerns(number_format = NumberFormatter.PERCENTAGE)
    private double attendancePercentage;
    private String grade;
    private boolean scholarshipEligible;

    public Student(StudentBuilder builder){
        this.studentId=builder.studentId;
        this.firstName=builder.firstName;
        this.lastName=builder.lastName;
        this.age=builder.age;
        this.subject=builder.subject;
        this.examScore=builder.examScore;
        this.attendancePercentage=builder.attendancePercentage;
        this.grade=builder.grade;
        this.scholarshipEligible=builder.scholarshipEligible;
    }

    public static class StudentBuilder{
        StudentBuilder(String studentId, Subject subject){
            this.studentId=studentId;
            this.subject=subject;
        }
        private String studentId;
        private String firstName;
        private String lastName;
        private int age;
        private Subject subject;
        private double examScore;
        private double attendancePercentage;
        private String grade;
        private boolean scholarshipEligible;

        public StudentBuilder setStudentId(String studentId){
            this.studentId=studentId;
            return this;
        }
        public StudentBuilder setFirstName(String firstName){
            this.firstName=firstName;
            return this;
        }
        public StudentBuilder setLastName(String lastName){
            this.lastName=lastName;
            return this;
        }
        public StudentBuilder setAge(int age){
            this.age=age;
            return this;
        }
        public StudentBuilder setSubject(Subject subject){
            this.subject=subject;
            return this;
        }
        public StudentBuilder setExamScore(double examScore){
            this.examScore=examScore;
            return this;
        }
        public StudentBuilder setAttendancePercentage(double attendancePercantage){
            this.attendancePercentage=attendancePercantage;
            return this;
        }
        public StudentBuilder setGrade(String grade){
            this.grade=grade;
            return this;
        }
        public StudentBuilder setScholarshipEligible(boolean scholarshipEligible){
            this.scholarshipEligible=scholarshipEligible;
            return this;
        }
        public Student build(){
            return new Student(this);
        }
    }
}
class WrongFormatException extends RuntimeException{
    public WrongFormatException(String message){
        super(message);
    }
    public WrongFormatException(String message, Throwable cause){
        super(message, cause);
    }
}
class FinalPrep {
    public static List<Student> loadStudents(String fileName) {
        List<Student> students=new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line=reader.readLine();
            if(line==null){
                throw new WrongFormatException("File is empty");
            }
            while((line=reader.readLine())!=null){
                String[] fields=line.split(",");
                if (fields[0].isEmpty() || fields[1].isEmpty()){
                    throw new WrongFormatException("Values are empty", new ClassCastException());
                }
                String examScoreStr=fields[5].isEmpty() ? "0.0" : fields[5];
                String subjectStr=fields[4].isEmpty() ? "UNKNOWN" : fields[4].toUpperCase();
                Subject subject=Subject.valueOf(subjectStr);
                String scholarShipEligibleStr=fields[8].isEmpty() ? "false" : fields[8].toLowerCase();
                boolean scholarshipEligible=Boolean.parseBoolean(scholarShipEligibleStr);

                students.add(new Student.StudentBuilder(fields[0], subject )
                        .setStudentId(fields[0])
                        .setFirstName(fields[1])
                        .setLastName(fields[2])
                        .setAge(Integer.parseInt(fields[3]))
                        .setSubject(subject)
                        .setExamScore(Double.parseDouble(fields[5]))
                        .setAttendancePercentage(Double.parseDouble(fields[6]))
                        .setGrade(fields[7])
                        .setScholarshipEligible(scholarshipEligible)
                        .build()
                );
            }

        } catch (IOException e) {
            throw new WrongFormatException("Error loading the file", e);
        }
        return students;
    }
    public static int numOfRows(List<Student> students){
        return students.size()-1;
    }
}
class ReportWriter{
    public static void writeReport(String outputFileName, List<Student> students) {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName))) {
            writer.write("studentId,firstName,lastName,age,subject,examScore,attendancePercentage,grade,scholarshipEligible\n");
            for(Student student : students){
                StringBuilder line=new StringBuilder();
                Field[] fields=Student.class.getDeclaredFields();
                for(Field field : fields){
                    field.setAccessible(true);
                    Object value=field.get(student);
                    WriteConcerns writeConcerns=field.getAnnotation(WriteConcerns.class);
                    if(writeConcerns!=null){
                        if(value instanceof String){
                            String strValue=(String) value;
                            switch(writeConcerns.case_format()){
                                case LOWER_CASE:
                                    value=strValue.toLowerCase();
                                    break;
                                case UPPER_CASE:
                                    value=strValue.toUpperCase();
                                    break;
                                case ORDINARY:
                                    break;
                                default:
                                    break;
                            }
                        }
                        if(value instanceof Integer){
                            if(writeConcerns.number_format()==NumberFormatter.PERCENTAGE){
                                value=value.toString()+"%";
                            }
                            if(writeConcerns.number_format()==NumberFormatter.COMMA){
                                DecimalFormat df = new DecimalFormat("#,###.##");
                                value=df.format(value);
                            }
                        }
                    }
                    line.append(value);
                    if(field!=fields[fields.length-1]){
                        line.append(",");
                    }

                }
                writer.write(line.toString()+"\n");
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
class StudentTest{
    static List<Student> students;
    @BeforeEach
    void setUp(){
        students=FinalPrep.loadStudents("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep8\\students_exam_data.csv");
    }
    @Test
    void isValuesEmpty_ThrownAnCustomException(){
        String faultyCSV="age,subject,examScore,date,attendancePercentage,grade";
        assertThrows(WrongFormatException.class,()->FinalPrep.loadStudents("faultyCSV"));
    }
    @Test
    void isFileLoaded_assertMultipleConditions(){
        assertAll(
                ()->assertEquals("S10001",students.get(0).getStudentId()),
                ()->assertEquals(students.size()-1,FinalPrep.numOfRows(students))
        );
    }
    @Test
    void ifFileLoaded_assertCauseIsFileNotFoundException(){
        String non_existents_file="non_existent_file.csv";
        RuntimeException thrownException=assertThrows(RuntimeException.class,()->FinalPrep.loadStudents("non_existent_file.csv"));
        assertTrue(thrownException.getCause() instanceof FileNotFoundException);
    }
}

public class MainRun{
    public static void main(String[] args) {
        List<Student> students=FinalPrep.loadStudents("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep8\\students_exam_data.csv");
        System.out.println("Students loaded successfully.");
        System.out.println("Number of students loaded: " + students.size());

        File dataFile = new File("C:\\Users\\User\\Downloads\\OOP-labs-main\\OOP-labs-main\\src\\main\\java\\org\\example\\Practice\\Practice9\\FinalPrep8\\students_exam_data.csv");
        String reportDirectory = dataFile.getParent(); // Get the directory where the CSV is located
        String outputFileName = reportDirectory + File.separator + "student_report.csv"; // Full path for the report

        ReportWriter.writeReport(outputFileName, students);

        String relativePath = "src/main/resources/student_report.csv"; // Or adjust based on your actual path
        ReportWriter.writeReport(relativePath, students);

    }
}




