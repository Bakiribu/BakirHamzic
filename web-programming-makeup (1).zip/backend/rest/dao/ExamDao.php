<?php

class ExamDao
{

  private $conn;

  /**
   * constructor of dao class
   */
  public function __construct()
  {
    try {
      /** TODO
       * List parameters such as servername, username, password, schema. Make sure to use appropriate port
       */

      /** TODO
       * Create new connection
       */
      echo "Connected successfully";
    } catch (PDOException $e) {
      echo "Connection failed: " . $e->getMessage();
    }
  }

  public function login($data) {}

  public function film_performance_report() {}

  public function delete_film($film_id) {}

  public function edit_film($film_id, $data) {}

  public function get_customers_report() {}

  public function get_customer_rental_details($customer_id) {}
}
